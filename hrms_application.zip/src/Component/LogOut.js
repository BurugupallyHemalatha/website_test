import React from 'react'
const LogOut =()=>{
    return(
        <div className='container'>
            <div className='card'>
                kohsdiuho
            </div>
        
        </div>
    )
}
export default LogOut;